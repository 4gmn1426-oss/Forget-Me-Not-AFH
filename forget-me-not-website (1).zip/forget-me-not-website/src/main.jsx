import React from 'react';
import { createRoot } from 'react-dom/client';
import { motion } from 'framer-motion';
import { Heart, Home, Phone, Mail, MapPin, ShieldCheck, Users, Utensils, Clock, Leaf, CalendarDays, CheckCircle2 } from 'lucide-react';
import './styles.css';

function Button({ children, variant = 'primary', className = '' }) {
  return <a className={`btn ${variant === 'outline' ? 'btn-outline' : 'btn-primary'} ${className}`} href="#contact">{children}</a>;
}

function Card({ children }) {
  return <div className="card">{children}</div>;
}

function App() {
  const services = [
    { icon: Clock, title: '24-Hour Support', text: 'Attentive care and supervision in a safe, home-like environment.' },
    { icon: Heart, title: 'Personalized Daily Care', text: 'Assistance with daily routines while honoring dignity, independence, and comfort.' },
    { icon: Utensils, title: 'Home-Cooked Meals', text: 'Nutritious meals prepared with warmth, consistency, and individual needs in mind.' },
    { icon: Users, title: 'Companionship', text: 'Meaningful connection, conversation, activities, and a sense of belonging.' },
    { icon: ShieldCheck, title: 'Safe Environment', text: 'A peaceful setting designed to help residents and families feel secure.' },
    { icon: Home, title: 'Family-Style Living', text: 'A smaller, more personal care setting where residents are known by name.' },
  ];

  const values = ['Compassionate care', 'Family-centered atmosphere', 'Respect and dignity', 'Warm, peaceful environment', 'Personalized attention', 'Trustworthy communication'];

  return (
    <main>
      <header className="site-header">
        <div className="header-inner">
          <div className="brand">
            <div className="brand-mark"><Leaf size={27}/><Heart className="mini-heart" size={17}/></div>
            <div><p className="brand-name">Forget Me Not</p><p className="brand-sub">Adult Family Home</p></div>
          </div>
          <nav>
            <a href="#about">About</a><a href="#services">Care</a><a href="#home">Our Home</a><a href="#contact">Contact</a>
          </nav>
          <Button>Schedule a Tour</Button>
        </div>
      </header>

      <section className="hero">
        <div className="glow glow-one"/><div className="glow glow-two"/>
        <div className="hero-grid">
          <motion.div initial={{opacity:0,y:18}} animate={{opacity:1,y:0}} transition={{duration:.7}}>
            <p className="eyebrow-pill">Warm care. Safe home. Treasured lives.</p>
            <h1>Where care feels like home.</h1>
            <p className="lead">Forget Me Not Adult Family Home provides a peaceful, family-style environment where residents are cared for with dignity, warmth, and personal attention.</p>
            <div className="hero-actions"><Button>Contact Us</Button><Button variant="outline">Learn About Our Care</Button></div>
          </motion.div>
          <motion.div initial={{opacity:0,scale:.96}} animate={{opacity:1,scale:1}} transition={{duration:.7,delay:.1}} className="hero-photo-wrap">
            <div className="hero-photo"><div className="photo-card"><p>A place to be known, loved, and cared for.</p><span>Replace this area with a warm photo of the home, living room, dining space, or front porch.</span></div></div>
          </motion.div>
        </div>
      </section>

      <section id="about" className="section about-grid">
        <div><p className="section-kicker">About Us</p><h2>Care rooted in compassion, dignity, and home.</h2></div>
        <div className="body-copy"><p>At Forget Me Not Adult Family Home, we believe every person deserves to feel safe, valued, and remembered. Our home was created to offer more than care — it was created to offer belonging.</p><p>We provide a warm, family-like environment where residents receive personalized support, meaningful connection, and daily care that honors who they are.</p></div>
      </section>

      <section id="services" className="section services-section">
        <div className="section-intro"><p className="section-kicker">Our Care</p><h2>Support for daily living in a peaceful home setting.</h2></div>
        <div className="services-grid">{services.map((item)=>{const Icon=item.icon;return <Card key={item.title}><Icon className="card-icon" size={38}/><h3>{item.title}</h3><p>{item.text}</p></Card>})}</div>
      </section>

      <section id="home" className="section home-grid">
        <div className="photo-grid"><div>Photo: living room</div><div>Photo: bedroom</div><div>Photo: dining area</div><div>Photo: outdoor space</div></div>
        <div><p className="section-kicker">Our Home</p><h2>Small-home care with a personal touch.</h2><p className="body-copy">Families choose Forget Me Not because they want their loved one to be more than a resident — they want them to be seen, cared for, and surrounded by warmth.</p><div className="values-grid">{values.map((value)=><div className="value-pill" key={value}><CheckCircle2 size={20}/><span>{value}</span></div>)}</div></div>
      </section>

      <section className="cta-section"><div><p className="section-kicker light">Next Step</p><h2>Looking for care for someone you love?</h2><p>We would be honored to answer your questions, share more about our home, and help you determine whether Forget Me Not is the right fit.</p></div><Button><CalendarDays size={19}/> Schedule a Tour</Button></section>

      <section id="contact" className="section contact-grid">
        <div><p className="section-kicker">Contact</p><h2>We’d love to connect with you.</h2><p className="body-copy">Reach out to ask questions, check availability, or schedule a visit.</p><div className="contact-list"><p><Phone size={20}/> Add phone number</p><p><Mail size={20}/> Add email address</p><p><MapPin size={20}/> Add city/state or general service area</p></div></div>
        <form className="contact-form" name="contact" method="POST" data-netlify="true"><input type="hidden" name="form-name" value="contact"/><input placeholder="Name" name="name"/><input placeholder="Email" name="email"/><input placeholder="Phone" name="phone"/><textarea placeholder="How can we help?" name="message"/><button type="submit">Send Message</button></form>
      </section>

      <footer><p>© 2026 Forget Me Not Adult Family Home. All rights reserved.</p><p>Compassionate care in a warm, family-like environment.</p></footer>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
